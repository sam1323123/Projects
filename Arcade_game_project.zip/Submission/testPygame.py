import pygame
import sys
from pygame.locals import*
import random
import math
import string
import copy

###################################### bullets class###############

class newProjectile(pygame.sprite.Sprite):
	def __init__(self, x=0,y=0, canvas=0):
		# image from http://th02.deviantart.net/fs71/PRE/i/2012/
		#177/4/8/misc_fire_elements_png_by_dbszabo1-d54y2r0.png
		super(newProjectile, self).__init__()
		self.width, self.height= 5,10
		self.image= pygame.Surface([self.width, self.height])
		self.image.set_alpha(0) #make transparent
		#image= pygame.image.load("testImg.png")
		#image= pygame.transform.scale(self.image, (40,40))
		#print type(self.image.blit(image,(0,0)))
		#print type(self.image)
		#self.image.fill([0,0,0])
		self.rect= self.image.get_rect(height=100)
		self.leftShift= self.width/2 #ceter of rectangle
		self.rect.x= x -self.leftShift
		self.rect.y=y
		self.vel = 80 #velocity of projectile
		self.damage = 10
		self.picture = pygame.image.load("bullets/7.png")
		self.picture = pygame.transform.rotate(self.picture, 180)
		picWidth, picHeight = 12,20
		self.picture = pygame.transform.scale(self.picture, (picWidth, picHeight))

	def move(self):
		self.rect.y-= self.vel

	def moveDown(self):
		self.rect.y += self.vel


class goonProjectile(newProjectile):
	def __init__(self, x=0,y=0, canvas=0):
		super(goonProjectile, self).__init__(x, y, canvas)
		self.rect= self.image.get_rect(height=50)
		self.leftShift= self.width/2 #ceter of rectangle
		self.rect.x= x -self.leftShift
		self.rect.y=y
		self.vel= 35  # goon projectiles are slower
		self.damage= 20 # damage done to player
		self.picture = pygame.image.load("bullets/7.png")
		#self.picture = pygame.transform.rotate(self.picture, 180)
		picWidth, picHeight = 12,20
		self.picture = pygame.transform.scale(self.picture, (picWidth, picHeight))

	def move(self):
		self.rect.y-= self.vel

	def moveDown(self):
		self.rect.y += self.vel


class aimedProjectile(newProjectile):
	def __init__(self ,x=0,y=0,dx=0,dy=0, canvas=0):
		super(aimedProjectile, self).__init__(x,y,canvas)
		self.dx= dx
		self.dy=dy
		self.damage = 20
		self.vel = 40
		self.picture = pygame.image.load("bullets/7.png")
		#self.picture = pygame.transform.rotate(self.picture, 180)
		picWidth, picHeight = 20,25
		self.picture = pygame.transform.scale(self.picture, (picWidth, picHeight))


	def move(self):
		self.rect.x+= self.dx
		self.rect.y+=self.dy



class homingMissle(pygame.sprite.Sprite):
	def __init__(self, x=0,y=0, *eGroups):
		super(homingMissle, self).__init__()
		self.width, self.height= 20,20
		self.image= pygame.Surface([self.width, self.height])
		self.rect= self.image.get_rect(width= 50, height=50)
		#set hitbox
		leftShift= self.width/2 #ceter of rectangle
		self.rect.x= x -leftShift
		self.rect.y=y
		self.vel = 20 #velocity of projectile
		self.picture= pygame.image.load("missile.png")
		picWidth, picHeight = 10, 40 #dimensions of graphic/sprite
		self.picture= pygame.transform.scale(self.picture, (picWidth,picHeight))
		self.orgPic = self.picture  #original pic orientation
		self.target = self.targetLock(eGroups)  # select missile target
		self.damage= 200 # damage to health for stronger enemytypes

	
	def targetLock(self, enemyGroups):  #remeber to add other enemy groups
		#select a target to shoot
		allEnemies= []
		for enemy in enemyGroups:
			#print enemy.sprites
			allEnemies+= enemy.sprites() 
			#add list of each enemy type
		if len(allEnemies)>0:
	 		return random.choice(allEnemies)
	 	else: return None

	def homeMissile(self, *enemyGroups):
		if (self.target == None): #no targets on screen
				self.rect.y-= self.vel
				return #skip following steps
		elif (not self.target.alive() or self.target.rect.y>720): #if target is destroyed
			# or target too far
		#find new target
			self.target = self.targetLock(enemyGroups)
			if (self.target == None): #no targets on screen
				self.rect.y-= self.vel
				return #skip following steps
		else:
			targetX= self.target.rect.x
			targetY = self.target.rect.y
			opp = targetX - self.rect.x #opp of triangle
			adj = targetY - self.rect.y #adj vert of triangle
			try:
				angle= math.degrees(math.atan(opp/adj)) #angle in degrees to target
			except:
				angle = 90 if adj>0 else 270 
				#target has no y component rotate leftor right by 90
			self.picture = self.orgPic
			self.picture= pygame.transform.rotate(self.picture, angle)
			# rotate missile pic to face target
			distance = (opp**2 + adj**2)**0.5 #pythag theorem
			try:
				dx = opp/distance * self.vel  #vector scaling of velocity
				dy = adj/distance * self.vel  #in case division by zero
			except: return
			self.rect.x+=dx   #move missile
			self.rect.y+=dy

	def explode(self): pass




######################### enemies and power ups class #####################		


class goons(pygame.sprite.Sprite):
	def __init__(self, x=0, y=0, canvas=0):
		super(goons, self).__init__()
		self.width, self.height= 60, 60
		self.image= pygame.Surface([self.width, self.height])
		self.image.set_alpha(0) #completely transparent at 0
		self.rect= self.image.get_rect(width=80)
		self.rect.x, self.rect.y= x, y
		self.radius=50 # for circle collision
		self.maxX= 800
		self.maxY= 800
		self.vertVel = random.choice([10,20])
		self.picture= pygame.image.load("spaceship1.png")
		self.picture= pygame.transform.rotate(self.picture, 180)
		self.picture= pygame.transform.scale(self.picture, (self.width, self.height))
		self.hp = -1
		self.value = 100
		#points worth

	def fireWeapon(self, enemyProjectileGroup, level):
		frequency = 80
		shootfreq= frequency/level #higher level shoot more often
		shoot = random.randint(0, shootfreq)  
		if shoot == 0 :   #weapon is fired
			x,y = self.rect.center
			bullet = goonProjectile(x, y)
			enemyProjectileGroup.add(bullet)   

	def move(self):
		dx=10 #initial movement
		if (self.rect.x >= self.maxX): #end of screen
			self.rect.x=0
		self.rect.x+= dx

	def moveDown(self):  
	# put conditions in move function to reduce looping checks later
		dy = self.vertVel
		if self.rect.y== self.maxY:
			self.rect.y= 0 -self.height 
		self.rect.y+= dy



class advancedEnemy(pygame.sprite.Sprite):
	# image from http://opengameart.org/sites/default/files/ship5.png
	def __init__(self, x=0, y=0, canvas=0):
		super(advancedEnemy, self).__init__()
		self.width, self.height= 70, 60
		self.image= pygame.Surface([self.width, self.height])
		self.image.set_alpha(0) #completely transparent at 0
		self.rect= self.image.get_rect(width=80)
		self.rect.x, self.rect.y= x, y
		self.radius=50 # for circle collision
		self.maxX= 800
		self.maxY= 800
		self.vel= 15 #speed of movement
		self.hp = 800
		self.picture= pygame.image.load("enemyShip.png")
		self.picture= pygame.transform.rotate(self.picture, 180)
		self.picture= pygame.transform.scale(self.picture, (self.width, self.height))
		self.moveForward = "11111"
		self.value = 1000 #points worth


	
	def hover(self, playerGroup): 
		if len(playerGroup.sprites())>0: #if player is still alive
			playerSprite= playerGroup.sprites()[0]
			playerY = playerSprite.rect.y 
			vertDist = playerY - self.rect.y # wert dist betewwen player and enemy
			if (self.rect.y<300 ):
				dy = self.vel 
			elif (self.rect.y>= 300):
				dy = 0
			if(0<vertDist<=200 ): # maintain distance of around 200 pix
				dy= -self.vel
			#else: dy = self.vel  # enemy is below plane
			self.rect.y = self.rect.y+ dy


	def strafe(self, playerGroup): 
		if len(playerGroup.sprites())>0: #if player is still alive
			playerSprite= playerGroup.sprites()[0]
			playerX = playerSprite.rect.x 
			horDist = playerX - self.rect.x # hor dist betewwen player and enemy
			if (self.rect.x> 700):  #problem here!!!!!!!
				dx = -self.vel
				self.rect.x = self.rect.x+ dx
				return 
			elif (self.rect.x< 50): 
				dx = self.vel # move down wards
				self.rect.x = self.rect.x+ dx
				return  #break if reach map bounds
			elif horDist<-100 :  # enemy is on right of player
				dx = -self.vel # move left
			elif horDist>100:
				dx = self.vel 
			#if centred at player, stay put
			else: dx= 0
			self.rect.x = self.rect.x+ dx

	def move(self, playerGroup):
		self.hover(playerGroup)
		self.strafe(playerGroup)



	def aimedShot(self, playerGroup, enemyAimedProjectileGroup): 
		playerSprite= playerGroup.sprites()[0] 
		targetX = playerSprite.rect.x 
		targetY = playerSprite.rect.y 
		adj = targetX - self.rect.center[0]
		opp = targetY - self.rect.center[1] # for vector movement of aimed shot
		distance = (opp**2 + adj**2)**0.5
		dx = distance * (adj/distance)
		dy = distance * (opp/distance)
		bullet = aimedProjectile(self.rect.center[0], self.rect.center[1], dx, dy)
		enemyAimedProjectileGroup.add(bullet)

	
	def burstShot(self, enemyProjectileGroup, enemyAimedProjectileGroup):
		dy = 60
		leftDx = -30
		rightDx = 30
		leftBullet = aimedProjectile(self.rect.center[0], self.rect.center[1], leftDx, dy)
		rightBullet = aimedProjectile(self.rect.center[0], self.rect.center[1], rightDx, dy)
		Bullet = goonProjectile(self.rect.center[0], self.rect.center[1])
		enemyProjectileGroup.add(Bullet)
		enemyAimedProjectileGroup.add(leftBullet, rightBullet)


	def fireWeapon(self, playerGroup, enemyProjectileGroup, enemyAimedProjectileGroup, level):
		frequency = 80
		shootfreq= frequency/level #higher level shoot more often
		shoot = random.randint(0, shootfreq)  
		if shoot == 0 :   #weapon is fired
			mode = random.choice([0,1])
			if mode == 0:
				self.aimedShot(playerGroup, enemyAimedProjectileGroup)
			else:
				self.burstShot(enemyProjectileGroup, enemyAimedProjectileGroup) 


class bossEnemy(pygame.sprite.Sprite):
	#picture from http://stardrivegame.com/forum/viewtopic.php?f=1&t=8938
	def __init__(self,x=0, y=0,level=1, canvas=0):
		super(bossEnemy, self).__init__()
		self.width, self.height=  180, 200
		self.image= pygame.Surface([self.width, self.height])
		self.image.set_alpha(0) #completely transparent at 0
		self.rect= self.image.get_rect(width=self.width)
		self.rect.x, self.rect.y= x, y
		self.maxX= 800
		self.maxY= 800
		self.vel= 5 #speed of movement
		self.hp = 1000*level
		listOfBossImages = []
		for i in xrange(1,5,1):
			image= pygame.image.load("bosses/boss%d.png"%i)
			listOfBossImages+=[image]
		self.picture = random.choice(listOfBossImages)
		self.picture= pygame.transform.rotate(self.picture, 180)
		self.picture= pygame.transform.scale(self.picture, (self.width, self.height))
		self.value = 10000*level #points worth
		self.moveCounter=0
		self.maintain=150
		#self.horMovement = self.chooseHorMovement()
		#self.vertMovement= self.chooseVertMovement()
		#self.moveForward="11111"


	def hover(self, playerGroup): 
		if len(playerGroup.sprites())>0: #if player is still alive
			playerSprite= playerGroup.sprites()[0]
			playerY = playerSprite.rect.y 
			vertDist = playerY - self.rect.y # wert dist betewwen player and enemy
			changePoint = 100
			if (self.moveCounter%changePoint == 0):
				self.maintain = random.choice([150,240,350])
			if (self.rect.y<self.maintain ):
				dy = self.vel 
			elif (self.rect.y>= self.maintain):
				dy = 0
			if(0<vertDist<=200 ): # maintain distance of around 200 pix
				dy= -self.vel
			#else: dy = self.vel  # enemy is below plane
			self.rect.y = self.rect.y+ dy


	def strafe(self, playerGroup): 
		if len(playerGroup.sprites())>0: #if player is still alive
			playerSprite= playerGroup.sprites()[0]
			playerX = playerSprite.rect.x 
			horDist = playerX - self.rect.x # hor dist betewwen player and enemy
			if (self.rect.x> 700): 
				dx = -self.vel
				self.rect.x = self.rect.x+ dx
				return 
			elif (self.rect.x< 50): 
				dx = self.vel # move down wards
				self.rect.x = self.rect.x+ dx
				return  #break if reach map bounds
			elif horDist<-100 :  # enemy is on right of player
				dx = -self.vel # move left
			elif horDist>100:
				dx = self.vel 
			#if centred at player, stay put
			else: dx= 0
			self.rect.x = self.rect.x+ dx


	def move(self, playerGroup):
		self.moveCounter+=1
		self.hover(playerGroup)
		self.strafe(playerGroup)

	
	def arcShot(self,enemyAimedProjectileGroup):
		dy = 60
		leftDx = -30
		rightDx = 30
		for angle in xrange(0,-361,-45):
			angRad = math.radians(angle) #convert to radians
			dy = -self.vel*math.sin(angRad)
			dx = self.vel*math.cos(angRad)
			bullet = aimedProjectile(self.rect.center[0], self.rect.center[1], dx, dy)
			enemyAimedProjectileGroup.add(bullet)
			#enemyAimedProjectileGroup.add()


	def fireWeapon(self, enemyAimedProjectileGroup, level):
		frequency = 140
		shootfreq= frequency/level #higher level shoot more often
		shoot = random.randint(0, shootfreq)  
		if shoot == 0 :   #weapon is fired
			mode = random.choice([0,1])
			self.arcShot(enemyAimedProjectileGroup)
	



class powerUps(pygame.sprite.Sprite): 
	#missile sprite from http://www.spriters-resource.com/arcade/ms2/sheet/53203/
	# http://fc02.deviantart.net/fs47/f/2009/212/a/7/
	#Tarydium_Stinger_Minigun_by_Seargent_Demolisher.png
	# heart http://pngimg.com/upload/heart_PNG695.png
	def __init__(self, x=0, y=0):
		super(powerUps, self).__init__()
		self.width, self.height= 30, 30
		self.image= pygame.Surface([self.width, self.height])
		self.image.set_alpha(0) #completely transparent at 0
		self.rect= self.image.get_rect(width=60, height=60)
		self.rect.x, self.rect.y= x, y
		self.radius=50 # for circle collision
		self.maxX= 800
		self.maxY= 800
		self.vel= 10 #speed of movement
		self.missilePic= pygame.image.load("missile.png")
		self.missilePic= pygame.transform.scale(self.missilePic, (self.width-10, 50))
		# scale differently to reduce image squishing
		self.minigunPic = pygame.image.load("minigun.png")
		self.minigunPic = pygame.transform.scale(self.minigunPic, (self.width, self.height))
		self.healthPic = pygame.image.load("heart.png")
		self.healthPic = pygame.transform.scale(self.healthPic, (self.width, self.height))
		self.powerUpsDict = {"missile":["missile", self.missilePic, 10], \
		"minigun":["minigun", self.minigunPic, 100], "health":["health", self.healthPic, 150]}
		self.type= None
		self.picture = None
		self.add= None


	def move(self):
		self.rect.y+= self.vel 

	def choosePowerUp(self):
		powerUpsList = ["missile"]+ ["minigun"]*2 +["health"]*3 
		# set 1:2:3 drop rate
		choice = random.choice(powerUpsList)
		self.type, self.picture, self.add= self.powerUpsDict[choice]
		#assign values to attribute



#################animation class########################
class explosions(pygame.sprite.Sprite):
	# explosions from http://members.gamedev.net/dfgames/explosion.png
	def __init__(self, x, y):
		super(explosions, self).__init__()
		self.x =x
		self.y = y
		self.largeExp1 = pygame.image.load("explosions/0.png")
		self.largeExp2 = pygame.image.load("explosions/3.png")
		self.largeExp3 = pygame.image.load("explosions/16.png")
		self.largeExp4 = pygame.image.load("explosions/19.png")
		self.largeWidth= self.largeHeight = 50 # size of large explosion
		self.smallWidth = self.smallHeight = 6
		explosionList = [self.largeExp1, self.largeExp2, \
		self.largeExp3, self.largeExp4]
		self.largeExplosionList = []
		self.smallExplosionList= []
		for image in xrange(len(explosionList)):
			img = pygame.transform.scale(explosionList[image], (self.largeWidth, self.largeHeight)) 
			# scale to large size
			self.largeExplosionList+= [img]
			if image == 0 or image == 3:
				img2 = pygame.transform.scale(explosionList[image], (self.smallWidth, self.smallHeight)) 
				self.smallExplosionList+= [img2]
		self.largeCount=0
		self.smallCount= 0 #animation sequence counter

	def largeExplosion(self, canvas):
		if self.largeCount<4:
			canvas.blit(self.largeExplosionList[self.largeCount], (self.x, self.y))
			self.largeCount+=1

	def smallExplosion(self, canvas):
		if self.smallCount<2:
			canvas.blit(self.smallExplosionList[self.smallCount], (self.x, self.y))
			self.smallCount+=1
		












################# player class ###################

class Player(pygame.sprite.Sprite):
	def __init__(self, x=0, y=0):
		super(Player, self).__init__()
		# initialise player
		self.playerWidth, self.playerHeight= 50,50
		self.playerSprite = pygame.image.load("spaceship1.png")
		self.playerSprite =  pygame.transform.scale(self.playerSprite, (self.playerWidth,self.playerHeight))
		# scale the player sprite size
		self.image= pygame.Surface([self.playerWidth, self.playerHeight])
		self.image.set_alpha(0)
		#make surface transparent
		hitboxX, hitboxY= 40,40
		shift = (self.playerWidth-hitboxX)/2 #to center hitbox
		self.rect= self.image.get_rect(x=x+shift, y=y+shift)
		# for collision purposes

	def moveHitbox(self, newX, newY):
		self.rect.x += newX
		self.rect.y+= newY
		# update player hitbox coordinates to track collision



################## enemy tactic and sprite spawn ###############

class enemyTactics(object):
	def __init__(self):
		self.winWidth, self.winHeight= 800, 800
		self.goonWidth= self.goonheight= goons().width  #width dimension of goon enemy type
		self.advancedEnemyWidth = advancedEnemy().width
		self.advancedEnemyHeight = advancedEnemy().height


	def randomGoonSpawn(self, spriteGroup, level):
		frequency= 120
		spawnFreq= frequency/level # higher level more enemies spawned
		spawn= random.randint(0, spawnFreq)
		if (spawn==0):
			goonX= random.randint(0, self.winWidth-self.goonWidth)
			goonY= 0- self.goonheight
			singleGoon= goons(goonX, goonY)
			spriteGroup.add(singleGoon)
			#print spriteGroup.sprites()

	def advancedEnemySpawn(self, spriteGroup, level):
		frequency= 150
		spawnFreq= frequency/level # higher level more enemies spawned
		spawn= random.randint(0, spawnFreq)
		if (spawn==0):
			enemyX= random.randint(0, self.winWidth-self.advancedEnemyWidth)
			enemyY= 0- self.advancedEnemyHeight
			singleEnemy= advancedEnemy(enemyX, enemyY)
			spriteGroup.add(singleEnemy)

	def bossEnemySpawn(self, bossGroup, level):
		bossHeight = 100
		if len(bossGroup.sprites())==0:
			startX= 0
			startY = 0- bossHeight
			boss= bossEnemy(startX, startY, level)
			bossGroup.add(boss)



class powerUpCreate(object):
	def __init__(self):
		self.winWidth, self.winHeight= 800, 800
		self.width = self.height =30 #dimensions of sprite

	def randomPowerUpSpawn(self, powerUpGroup):
		frequency=100
		spawn = random.randint(0, frequency)
		if spawn == 0:
			powerUpX= random.randint(0, self.winWidth-self.width)
			powerUpY = 0
			newPowerUp = powerUps(powerUpX, powerUpY)
			newPowerUp.choosePowerUp()
			powerUpGroup.add(newPowerUp) 





##################setting class####################

class Settings(object):
	def __init__(self, startX, startY, fontSize, canvas):
		self.canvas = canvas
		self.refX = startX
		self.refY = startY
		self.rightShift = 200
		self.rectDict = {"diff":[], "music":[], "quality":[]}
		self.fontType = "verdana.ttf"
		self.fontSize=40
		self.fontColour = (180,180,0) # random colour 
		self.otherColour = (255, 255, 255) #colour of button
		self.diff = "med"
		self.width =100
		self.call= None
		self.x = 0
		self.y = 0
		self.vol=1.0
		self.mainMenu = False
		self.setting= True
		self.spec="low"
		self.sensitivity= 40
		self.SFXvol=1.0


	def changeDifficulty(self, posX, posY):
		startX = self.refX + self.rightShift
		startY = self.refY
		highDiff = pygame.font.SysFont(self.fontType, self.fontSize)
		highDiff = highDiff.render("high", True, self.fontColour)
		width, height = test.get_width(), test.get_height()
		lowDiff = pygame.font.SysFont(self.fontType, self.fontSize)
		lowDiff = lowDiff.render("low", True, self.fontColour)
		medDiff = pygame.font.SysFont(self.fontType, self.fontSize)
		medDiff = medDiff.render("med", True, self.otherColour)
		space = 10
		space = width+ space
		listOfCoords = [(startX, startY), (startX+space, startY), \
		(startX+2*space, startY)]  # coords of "low" "med" and "high"
		self.rectDict["diff"]= listOfCoords
		if ((int(posX) - startX)/space ==0):
			lowDiff = lowDiff.render("low", True, self.otherColour)
			medDiff = medDiff.render("med", True, self.fontColour)
		elif ((int(posX) - startX)/space ==1):
			medDiff = medDiff.render("med", True, self.otherColour)
		elif ((int(posX) - startX)/space ==2):
			highDiff = highDiff.render("high", True, self.otherColour)
			medDiff = medDiff.render("med", True, self.fontColour)

	def drawWhiteBar(self, x, y):
		#self.width= 50
		height =30
		image = pygame.Surface((self.width, height))
		image.fill((255,255,255))
		self.canvas.blit(image, (x,y))

	def drawRedBar(self,x,y,width):
		height =30
		image = pygame.Surface((width, height))
		image.fill((255,0,0)) 
		self.canvas.blit(image, (x,y))


	def changeMusicVolume(self, x, y, manual=0):  #manual parameter to set volume manually
		startX = self.refX + self.rightShift  #start x coord
		startY = self.refY + self.fontSize #starty cooord
		amount = float(x - startX)/self.width  #proportion of max volume
		self.vol = amount if 0<=amount<=1 else self.vol #prevent overshot or undershot
		#print self.vol
		#print amount
		if 0<=amount<=1 or manual!=0: #if within the box 
			#self.vol = amount
			self.drawWhiteBar(startX, startY)
			width = int(amount*self.width) if manual==0 else manual
			#print width 
			self.drawRedBar(startX,startY, width)
		else: # if click outside white bar
			#print self.vol*self.width
			self.drawWhiteBar(startX, startY)
			self.drawRedBar(startX,startY, int(self.vol*self.width))
			#self.changeMusicVolume(0,0,(int(self.vol*self.width))) 


	def changeSFXVolume(self, x, y, manual=0):  #manual parameter to set volume manually
		startX = self.refX + self.rightShift  #start x coord
		startY = self.refY  #starty cooord
		amount = float(x - startX)/self.width  #proportion of max volume
		self.SFXvol = amount if 0<=amount<=1 else self.SFXvol #prevent overshot or undershot
		if 0<=amount<=1 or manual!=0: #if within the box 
			#self.vol = amount
			self.drawWhiteBar(startX, startY)
			width = int(amount*self.width) if manual==0 else manual
			#print width 
			self.drawRedBar(startX,startY, width)
		else: # if click outside white bar
			#print self.vol*self.width
			self.drawWhiteBar(startX, startY)
			self.drawRedBar(startX,startY, int(self.SFXvol*self.width))
			#self.changeMusicVolume(0,0,(int(self.vol*self.width))) 

	def changeSensitivity(self, x, y, manual=0):  #manual parameter to set volume manually
		startX = self.refX + self.rightShift  #start x coord
		startY = self.refY + 2*self.fontSize #starty cooord
		maxSen =40
		amount = float(x - startX)/self.width  #proportion of max volume
		self.sensitivity = amount* maxSen if 0<=amount<=1 else self.sensitivity #prevent overshot or undershot
		#print self.sensitivity
		#print amount
		if 0<=amount<=1 or manual!=0: #if within the box 
			self.drawWhiteBar(startX, startY)
			width = int(amount*self.width) if manual==0 else (manual/maxSen*self.width)
			#print width 
			self.drawRedBar(startX,startY, width)
		else: # if click outside white bar
			#print self.vol*self.width
			self.drawWhiteBar(startX, startY)
			self.drawRedBar(startX,startY, self.sensitivity)
			#self.changeMusicVolume(0,0,(int(self.vol*self.width)))

	def changeSpecs(self, x, y):
		startX = self.refX + self.rightShift
		startY = self.refY + (3*self.fontSize)
		text1 = "Low"
		text2 = "High"
		lowTextF= pygame.font.SysFont(self.fontType, self.fontSize)
		lowText = lowTextF.render(text1, True, self.fontColour)
		lowTextWidth = lowText.get_width()
		space = 5
		highTextF= pygame.font.SysFont(self.fontType, self.fontSize)
		hightText = highTextF.render(text2, True, self.fontColour)
		#initialise font surfaces
		hightTextWidth= hightText.get_width()
		if (startX<=x<=startX+lowTextWidth ):  #if clicked on low
			self.spec= "low"
		elif (((startX+lowTextWidth+space)<=x<=(startX+lowTextWidth+space+hightTextWidth))\
			): #if click on high
			self.spec="high"
		if self.spec=="low":  #render surfaces
			lowText1 = lowTextF.render(text1, True, self.fontColour, self.otherColour)
			self.canvas.blit(lowText1, (startX, startY))
			self.canvas.blit(hightText, ((startX+lowTextWidth+space), startY))
		elif self.spec== "high":
			highText1 = highTextF.render(text2, True, self.fontColour, self.otherColour)
			self.canvas.blit(lowText, (startX, startY))
			self.canvas.blit(highText1, ((startX+lowTextWidth+space), startY))






	def backToMain(self,x,y,manual=0):
		startX = self.refX + self.rightShift  #start x coord
		startY = self.refY + 7*self.fontSize
		text = "Main Menu"
		if manual == 0:
			self.mainMenu=True
		printText = pygame.font.SysFont(self.fontType, self.fontSize)
		printText = printText.render(text, True,\
		self.fontColour, self.otherColour)
		self.canvas.blit(printText, (startX, startY))





	def selectChange(self, x, y):
		self.mainMenu= False #reset to false each iteration 
		self.setting=True
		self.x = x
		self.y = y
		startX = self.refX+ self.rightShift  #x coord of all drawings
		startY = self.refY
		selectionIndex = (y - startY)/self.fontSize
		if selectionIndex== 1:
			self.call = 1
			self.changeMusicVolume(x,y)
		elif selectionIndex == 0:
			self.call=0
			self.changeSFXVolume(x,y)
		elif selectionIndex==2:
			self.call=2
			self.changeSensitivity(x,y)
		elif selectionIndex==3:
			self.call=3
		elif selectionIndex== 7:
			self.call = "main"  #return to main at
			self.mainMenu=True  #change parameters to set for main game
			self.setting= False
		else:
			self.call = None

	def drawAll(self):
		#self.changeMusicVolume(0,0,50)
		#self.drawWhiteBar(self.refX + self.rightShift, self.refY + self.fontSize )
		#self.drawRedBar(self.refX + self.rightShift, self.refY + self.fontSize , 30)
		if self.call == 1:
			self.changeMusicVolume(self.x, self.y)  #this works
		elif self.call==0:
			self.changeSFXVolume(self.x, self.y)
		elif self.call == 2:
			self.changeSensitivity(self.x,self.y)
		elif (self.call==3):
			self.changeSpecs(self.x, self.y)
		elif (self.call=="main"):
			self.backToMain(0,0,0)	
		# draw every thing
		self.changeMusicVolume(0,0,int(self.vol*self.width))  #use the else to draw everything
		self.changeSFXVolume(0,0,int(self.SFXvol*self.width))
		self.changeSensitivity(0,0,self.sensitivity)
		self.backToMain(0,0,1)
		self.changeSpecs(-1,-1)
		
		

		
	


####################### game #######################




class TermProject(object):
	def __init__(self):
		self.width=800
		self.height=800
		fps= 30 #frames
		pygame.init()
		self.gameTimer = pygame.time.Clock()



	def drawBlit(self):
		image= pygame.image.load("testImg.png")
		image= pygame.transform.scale(self.image, (40,40))

	

    #def loadHighScore():pass

	def initPlayer(self):
		# initialise player
		self.playerGroup= pygame.sprite.Group()
		self.newProjectileList= pygame.sprite.Group()
		self.missileProjectile = pygame.sprite.Group()
		self.playerGroup.add(Player(self.tankX, self.tankY))
		self.vel=40
		self.numofLives= 2
		self.hp=300
		self.homingMissileAmmo = 10
		self.machineGunAmmo = 50
		self.ammoList= [999, self.machineGunAmmo, self.homingMissileAmmo]
		self.gameOver= False
		self.gamePaused = False

	def initEnemies(self):
		self.enemyProjectiles= pygame.sprite.Group()
		self.enemies= pygame.sprite.Group()
		self.randomGoons= pygame.sprite.Group()
		self.advancedEnemies= pygame.sprite.Group()
		self.enemyAimedProjectileGroup = pygame.sprite.Group()
		self.bossGroup= pygame.sprite.Group()
		self.bossSpawnCounter =0

	def initPowerUps(self):
		self.powerUpGroup = pygame.sprite.Group()
		self.powerUpCreation = powerUpCreate()

	def initGraphics(self):
		self.largeExplosionGroup = pygame.sprite.Group()
		self.smallExplosionGroup = pygame.sprite.Group()

	def initSounds(self):
		# explosion sound from http://www.shockwave-sound.com
		#/sound-effects/explosion-sounds/explode1.wav
		#reload sound from http://www.freespecialeffects.co
		#.uk/soundfx/weapons/shotgun_1.wav
		# missile sound from http://soundbible.com/1794-Missle-Launch.html
		# mainsound obtained from http://www.gamethemesongs.
		#com/Mass_Effect_-_33_-_Final_Assault.html
		#machine gun from http://soundbible.com/1386-50-Cal-Machine-Gun.html
		self.mainSoundChannel= pygame.mixer.Channel(1)
		self.mainSound = pygame.mixer.Sound("masseffect3.wav")
		self.machineGunChannel = pygame.mixer.Channel(2)
		self.machineGunAudio=pygame.mixer.Sound("50Cal.wav")
		self.rocketLaunchChannel= pygame.mixer.Channel(3)
		self.rocketLaunchAudio = pygame.mixer.Sound("Missile1.wav")
		self.explodeChannel= pygame.mixer.Channel(4)
		self.explodeAudio = pygame.mixer.Sound("explode1.wav")
		self.reloadChannel = pygame.mixer.Channel(5)
		self.reloadAudio = pygame.mixer.Sound("reload.wav")



	def changeSFXvol(self, vol):
		for i in xrange(2,6):
			pygame.mixer.Channel(i).set_volume(vol)


	def initImages(self):
		# turret from http://img1.wikia.nocookie.net/
		#__cb20090107122113/fallout/images/7/7e/MK-I_turret.png
		#gameoverImage from http://www.chowarth.co.uk/wp-content
		#/uploads/2013/04/spaceinvadersgameover.png
		width = height = 30
		self.missilePic= pygame.image.load("missile.png")
		self.missilePic= pygame.transform.scale(self.missilePic, (width-10, 50))
		# scale differently to reduce image squishing
		self.minigunPic = pygame.image.load("minigun.png")
		self.minigunPic = pygame.transform.scale(self.minigunPic, (width, height))
		self.turretPic = pygame.image.load("turret.png")
		self.turretPic = pygame.transform.scale(self.turretPic, (width, height))
		self.weaponImageList= [self.turretPic, self.minigunPic, self.missilePic]
		self.deathPic = pygame.image.load("death.png")
		upshift= 70 #shift image up
		self.deathPic=pygame.transform.scale(self.deathPic, (self.width, self.height-upshift))

	@staticmethod
	def readFile(filename, mode="rt"):
		with open(filename, mode) as fin:
			return fin.read()
    
	@staticmethod
	def writeFile(filename, contents, mode="wt"):
		with open(filename, mode) as fout:
			fout.write(contents)

	def loadHighscore(self):
		try: 
			self.highScoreString=TermProject.readFile("gameHighScore.txt")
		except: 
			self.highScoreString= None

	def saveHighScore(self):
		if self.highScoreString==None :
			scoreToSave= """%012d"""%self.score
		else:
			scoreToSave= self.highScoreString+ """\n%012d"""%self.score
		TermProject.writeFile("gameHighScore.txt", scoreToSave)

	def topScores(self):
		try:
			listOfStrings = self.highScoreString.split("\n")
		except:
			listOfStrings = []
		filler= "%011d"%0 #string of 12 0s
		numOfScores = 5
		if len(listOfStrings)<numOfScores:
			listOfStrings+= [filler]*(numOfScores-len(listOfStrings))
			return sorted(listOfStrings)[::-1]
		else:
			result = sorted(listOfStrings)
			result= result[::-1] #reverse to descending order
			return result[0:5]

	def newHighScore(self):
		scoreToSave= """%012d"""%self.score
		try:
			listOfStrings = self.highScoreString.split("\n")
		except:
			listOfStrings = [None]
		if scoreToSave> sorted(listOfStrings)[-1]:
			return True
		else:
			return False


	def respawn(self):
		if self.numofLives>0:
			self.hp =300
			self.playerGroup.empty() #remove all sprites in this group
			#self.playerGroup= pygame.sprite.Group()
			self.tankX, self.tankY= 400, 640 #initialise new ship
			self.playerGroup.add(Player(self.tankX, self.tankY))
			self.numofLives -=1 
			# i num of lives if more than 1
		elif (self.numofLives<=0):
			self.gameOver = True
			self.saveHighScore()



	def restartGame(self):
		self.initAnimation()
		self.mainMenu = False
		self.settings = False
		self.startGame= True
		#self.gameQuality = 

	def initBackGround(self):
		backPic=pygame.image.load("mainMenu.png")
		backPic2 = pygame.image.load("Space.png")
		chosenBack = random.choice([backPic, backPic2])
		self.background= pygame.transform.scale(chosenBack, (1000,1000))
		imageSize = 1000
		self.imgX= 400
		self.ImgY= 400



	def backgroundImage(self, canvas):
		#self.canvas.blit(backpic, (0,0))
		imageSize = 1000
		if self.gameQuality=="low":
			self.canvas.fill((0,20,60)) 
		else:
			self.canvas.blit(self.background, (0,self.backY))
			self.canvas.blit(self.background, (0,self.backY+ imageSize)) 
			self.backY+= 4 if self.backY<=0 else -1000  #scrolling



	def createTank(self, x, y):
		if len(self.playerGroup.sprites())>0:
		# source of image http://opengameart.org/sites/default/files/styles/watermarked/public/spaceship.pod_.1.png
			midX= x
			midY= y
			r= self.playerGroup.sprites()[0].playerWidth/2 #shift left by half
			image= self.playerGroup.sprites()[0].playerSprite
			#call image saved in player sprite class
			#pygame.draw.rect(self.canvas,(10,30,40), (midX-r, midY-r, 2*r, 2*r))
			#self.canvas.blit(image, (self.tankX, self.tankY))
			#pygame.draw.circle(self.canvas,(120,30,40), (midX, midY), r/2)
			#pygame.draw.line(self.canvas,(0,0,0), (midX, midY), (midX, midY-30), 8)
			self.canvas.blit(image, (self.tankX-r,self.tankY))

	def moveTank(self, dx, dy):
		playerWidth, playerHeight = 50,50
		if len(self.playerGroup.sprites())>0:
			self.tankX, self.tankY= self.tankX+dx, self.tankY+dy
			if self.tankX<=(0-playerWidth/2): #left bound
				self.tankX= self.width+(playerWidth/2)
			elif (self.tankX >= (self.width+playerWidth/2)):
				self.tankX = 0-playerWidth/2 #move to oppsite
			if self.tankY+playerHeight >= self.height:
				self.tankY = self.height- playerHeight
			elif self.tankY <= 0:
				self.tankY = 0
			self.playerGroup.sprites()[0].moveHitbox(dx, dy)


	def initAnimation(self):
		#self.initSettings()
		self.initImages()
		self.gameOver= False
		self.startGame=False
		self.mainMenu = True
		self.settings = False
		self.highScoreMenu= False
		self.instructionsMenu= False
		#self.testImage= pygame.image.load("Spirals.png")
		#self.testImage= pygame.transform.scale(self.testImage, (80,80))
		self.tankX, self.tankY= 400,600
		self.gameQuality= self.settingClass.spec  # set quality of game
		#self.backgroundImage(self.canvas)
		self.initBackGround()
		self.initPlayer()
		self.initEnemies()
		self.initPowerUps()
		self.initGraphics()
		self.loadHighscore()
		#self.initSounds()
		self.enemyAI= enemyTactics()
		self.allSprites= pygame.sprite.Group() #do I need this ???
		#self.enemies.add(goons(0,100)) #for testing
		#self.allSprites.add(goons(0,100)) #for testing
		self.createTank(self.tankX, self.tankY)
		self.startTimer = 0
		self.dy=0
		self.dx=0
		self.gunFired= False
		self.gunType= 0
		self.weapons= {"normalGun": self.createNormalGun, \
		"machineGun": self.createMachineGun, "homingMissile":self.createHomingMissile}
		 #dict of all weapon functions
		self.availableWeapons= ["normalGun", "machineGun", "homingMissile"]
		self.score= 0
		self.backY = -1000 # for scrolling background
		self.level=1  #curren level of difficulty
		self.enemyNumCap = 2 #starting Num of enemies

		


	def levelChecker(self):  #works now
		if self.level <= 5: #not confirmed yet
			criticalNum =20000
			lvlChangeScore = criticalNum*self.level # score to increase difficulty
			currentLevel = self.level+ self.score/lvlChangeScore
			self.level = currentLevel #change level based on score


	def initSound(self):
		# sound obtained from http://www.gamethemesongs.
		#com/Mass_Effect_-_33_-_Final_Assault.html
		self.mainSoundChannel= pygame.mixer.Channel(1)
		self.mainSound = pygame.mixer.Sound("masseffect3.wav")



	def createNormalGun(self):
		bullet= newProjectile(self.tankX, self.tankY)
		self.newProjectileList.add(bullet)
		#self.allSprites.add(bullet)

	def createMachineGun(self):
		spread = [i for i in xrange(-3,4,1)]
		width = newProjectile().width
		startIndex= -2
		if self.machineGunAmmo>0:
			for bullet in xrange(startIndex,2):
				if bullet <0:
					shift = random.choice(spread)  #create spread from recoil
					newBullet= newProjectile(shift+self.tankX+(bullet*2)*width, self.tankY) 
				else:
					shift = random.choice(spread)
					newBullet= newProjectile(shift+self.tankX+((bullet*2+1)*width), self.tankY)
				#create new projectile 
				self.newProjectileList.add(newBullet)
			self.machineGunAmmo-=1  #reduce ammo reserves
				#self.allSprites.add(newBullet)

	def createHomingMissile(self):
		if self.homingMissileAmmo>0:
			missile = homingMissle(self.tankX, self.tankY, self.randomGoons,\
			 self.advancedEnemies, self.bossGroup)
			self.missileProjectile.add(missile)
			self.homingMissileAmmo-=1 #reduce ammo reserves

	#def drawProjectiles(self):
	#	for proj in self.projectileList:
	#		proj.drawProjectile(self.canvas)

	def selectGun(self):
		self.gunType+=1
		self.gunType= self.gunType% len(self.availableWeapons)
		# select weapon from available weapon list
		#change self.gunType int value to select from list of available weapons

	def selectGunLeft(self):
		if self.gunType==0:
			self.gunType = len(self.availableWeapons)-1
			#wrap around
		else: self.gunType-=1

	def playerEnemyCollision(self):
		#if len(pygame.sprite.groupcollide(self.playerGroup, self.enemies, True, True))>0:
		#	self.respawn()
		if (len(pygame.sprite.groupcollide(self.playerGroup, self.randomGoons, True, True))>0):
			self.respawn()
		elif (len(pygame.sprite.groupcollide(self.playerGroup, self.advancedEnemies, True, True))>0):
			self.respawn()
		elif (len(pygame.sprite.groupcollide(self.playerGroup, self.bossGroup, True, False))>0):
			self.respawn()
		#print self.gameOver
		#This works. Remove collided objects from their respective groups
		#pygame.sprite.groupcollide(self.enemies, self.missileProjectile, True, True)

	def missileEnemyCollision(self):
		missilesCollided=[]
		enemiesKilled= []
		for missile in self.missileProjectile.sprites():
			if len(pygame.sprite.spritecollide(missile, self.bossGroup, False))>0 :
				missilesCollided+= [missile]  # bullet hit enemy
				self.largeExplosionGroup.add(explosions(missile.rect.x, missile.rect.y))
			for enemy in pygame.sprite.spritecollide(missile, self.bossGroup, False):
				enemy.hp -= missile.damage
			enemiesKilled+= pygame.sprite.spritecollide(missile, self.bossGroup, False)
		for missile in self.missileProjectile.sprites():
			if len(pygame.sprite.spritecollide(missile, self.advancedEnemies, False))>0 :
				missilesCollided+= [missile]  # bullet hit enemy
				self.largeExplosionGroup.add(explosions(missile.rect.x, missile.rect.y))
			enemiesKilled+= pygame.sprite.spritecollide(missile, self.advancedEnemies, False)
		for missile in self.missileProjectile.sprites():
			if len(pygame.sprite.spritecollide(missile, self.randomGoons, False))>0 :
				missilesCollided+= [missile]  # bullet hit enemy
				self.largeExplosionGroup.add(explosions(missile.rect.x, missile.rect.y))
			enemiesKilled+= pygame.sprite.spritecollide(missile, self.randomGoons, False)
		#pygame.sprite.groupcollide(self.randomGoons, self.missileProjectile, True, True)
		#pygame.sprite.groupcollide(self.advancedEnemies, self.missileProjectile, True, True)
		for missile in self.missileProjectile.sprites():
			if (missile.rect.y> 800 or missile.rect.y<0 -(missile.height)):
				missile.kill()
		for enemy in enemiesKilled:
			if type(enemy)== bossEnemy:
				if enemy.hp<=0:
					enemy.kill()  #kill is a sprites
					self.explodeChannel.play(self.explodeAudio, loops=1, maxtime=2000)
					self.largeExplosionGroup.add(explosions(missile.rect.x, missile.rect.y))
					self.largeExplosionGroup.add(explosions(enemy.rect.center[0], enemy.rect.center[1]))
					self.largeExplosionGroup.add(explosions(enemy.rect.x+enemy.rect.width, enemy.rect.center[1]))
					self.explodeChannel.play(self.explodeAudio, loops=1, maxtime=2000)
					self.score+=enemy.value
			else:
				enemy.kill()  #kill is a sprites
				self.explodeChannel.play(self.explodeAudio, loops=1, maxtime=2000)
				self.largeExplosionGroup.add(explosions(missile.rect.x, missile.rect.y))
				self.score+=enemy.value
		for missiles in missilesCollided:
			missiles.kill()
			self.explodeChannel.play(self.explodeAudio, loops=1, maxtime=2000)


	def playerBulletCollision(self):
		bulletsCollided=[]
		enemiesKilled= []
		for sprite in self.newProjectileList.sprites():
			if len(pygame.sprite.spritecollide(sprite, self.advancedEnemies, False))>0 :
				bulletsCollided+= [sprite]  # bullet hit enemy
				self.smallExplosionGroup.add(explosions(sprite.rect.x, sprite.rect.y))
			enemiesKilled+= pygame.sprite.spritecollide(sprite, self.advancedEnemies, False)
			for enemy in enemiesKilled:
				enemy.hp -= sprite.damage
		for sprite in self.newProjectileList.sprites():
			if len(pygame.sprite.spritecollide(sprite, self.randomGoons, False))>0 :
				bulletsCollided+= [sprite]
				self.smallExplosionGroup.add(explosions(sprite.rect.x, sprite.rect.y))
			enemiesKilled+= pygame.sprite.spritecollide(sprite, self.randomGoons, False)
		for sprite in self.newProjectileList.sprites():
			if len(pygame.sprite.spritecollide(sprite, self.bossGroup, False))>0 :
				bulletsCollided+= [sprite]
				self.smallExplosionGroup.add(explosions(sprite.rect.x, sprite.rect.y))
			enemiesKilled+= pygame.sprite.spritecollide(sprite, self.bossGroup, False)
			for enemy in pygame.sprite.spritecollide(sprite, self.bossGroup, False):
				enemy.hp -= sprite.damage
		#required to prevent bullets from phasing through killed enemies	
		for sprite in bulletsCollided:
			sprite.kill() #remove from all groups containing it
		for enemy in enemiesKilled: 
			if enemy.hp< 0:
				self.largeExplosionGroup.add(explosions(enemy.rect.x, enemy.rect.y))
				if type(enemy)== advancedEnemy:  #advanced enemy worth more
					self.score+= enemy.value
				elif (type(enemy)==bossEnemy):
					self.score+=enemy.value
					self.largeExplosionGroup.add(explosions(enemy.rect.center[0], enemy.rect.center[1]))
					self.largeExplosionGroup.add(explosions(enemy.rect.x+enemy.rect.width, enemy.rect.center[1]))
					self.explodeChannel.play(self.explodeAudio, loops=1, maxtime=2000)
				else: self.score += enemy.value
				enemy.kill() #REMOVE FROM ALL GROUPS CONTAINING IT
				self.explodeChannel.play(self.explodeAudio, loops=1, maxtime=2000)	

	def enemyBulletCollision(self):
		bulletsCollided=[]
		#enemiesKilled= []
		for sprite in self.enemyProjectiles.sprites():
			if len(pygame.sprite.spritecollide(sprite, self.playerGroup, False))>0 :
				bulletsCollided+= [sprite]  # bullet hit enemy
			#enemiesKilled+= pygame.sprite.spritecollide(sprite, self.enemies, False)
		for sprite in self.enemyAimedProjectileGroup.sprites():
			if len(pygame.sprite.spritecollide(sprite, self.playerGroup, False))>0 :
				bulletsCollided+= [sprite]
		damage = len(bulletsCollided) * goonProjectile().damage
		#calculate damage done to ship
		for sprite in bulletsCollided:
			sprite.kill() #remove from all groups containing bullets
		self.hp-= damage
		if self.hp< 0: #no more health left
			self.respawn() #respawn checks whether death occurred

	def playerPowerCollision(self):
		if not self.gameOver:  #player group contains sprites
			if len(self.playerGroup.sprites())>0:
				playerSprite = self.playerGroup.sprites()[0] 
				collectedPowerUps = pygame.sprite.spritecollide(playerSprite, self.powerUpGroup, False)
				for powerUp in collectedPowerUps:
					powerType = powerUp.type
					addAmount = powerUp.add
					if powerType == "health":
						self.hp += addAmount
						if self.hp>300: #cap at 300
							self.hp =300
							if self.numofLives <8: #cap at 8
								self.numofLives+=1
					elif powerType == "missile":
						self.homingMissileAmmo+= addAmount
					elif powerType == "minigun":
						self.machineGunAmmo+= addAmount
						#print self.machineGunAmmo,self.ammoList[self.gunType]
					powerUp.kill()
					self.reloadChannel.play(self.reloadAudio, loops=1, maxtime=200)	
			self.ammoList= [999, self.machineGunAmmo, self.homingMissileAmmo]
				

	def difficultyScaler(self): 
		#cap enemy spawn frequency
		#cap total number of enemies
		#cap enemy aggresiveness
		currentLevel = self.level
		baseNumofEnemies = 2
		enemyNumCap = self.level* baseNumofEnemies
		self.enemyNumCap = enemyNumCap


	def checkOnScreenEnemies(self):
		listOfEnemyGroups = [self.randomGoons, self.advancedEnemies]
		totalEnemies = 0
		for group in listOfEnemyGroups:
			numOfEnemies = len(group.sprites())
			totalEnemies+= numOfEnemies
		if totalEnemies< self.enemyNumCap:
			return True
		else: return False

	def checkBossSpawn(self):
		spawnPoint = 25000 + (self.level*5000) #score multiples that determine spawn
		if (self.score/spawnPoint> self.bossSpawnCounter):
			self.bossSpawnCounter = self.score/spawnPoint
			return True
		else: return False



	def checkCollision(self):
		self.playerEnemyCollision()
		self.enemyBulletCollision()
		self.playerBulletCollision()
		self.missileEnemyCollision()
		self.playerPowerCollision()

	def drawEnemy(self, *args):
		for group in args:
			for enemy in group.sprites():
				image = enemy.picture
				x= enemy.rect.x
				y= enemy.rect.y
				self.canvas.blit(image, (x,y))

	def drawHomingMissile(self):
		for missile in self.missileProjectile.sprites():
			image= missile.picture
			x= missile.rect.x
			y=missile.rect.y
			self.canvas.blit(image, (x,y))

	def drawBullets(self):
		for bullet in self.newProjectileList.sprites():
			image = bullet.picture
			x,y = bullet.rect.x-bullet.leftShift, bullet.rect.y
			self.canvas.blit(image, (x,y))
		for bullet in self.enemyProjectiles.sprites():
			image = bullet.picture
			x,y = bullet.rect.x-bullet.leftShift, bullet.rect.y
			self.canvas.blit(image, (x,y))
		for bullet in self.enemyAimedProjectileGroup.sprites():
			image = bullet.picture
			x,y = bullet.rect.x-bullet.leftShift, bullet.rect.y
			self.canvas.blit(image, (x,y))


	def drawPowerUps(self):
		for power in self.powerUpGroup.sprites():
			image = power.picture
			x,y = power.rect.x, power.rect.y
			self.canvas.blit(image, (x,y))

	def drawExplosions(self):
		for exp in self.smallExplosionGroup.sprites():
			exp.smallExplosion(self.canvas)
			if exp.smallCount >=2:
				exp.kill()
		for exp in self.largeExplosionGroup.sprites():
			exp.largeExplosion(self.canvas)
			if exp.smallCount >=4:
				exp.kill()




	def drawHUD(self):
		startX = 10
		text1 = "HP: %d  Lives: %d  Current Weapon:"%(self.hp, self.numofLives)
		availableWeapons= ["Normal Gun", "Minigun", "Homing Missile"]
		text2 = "Ammo: %d"%(self.ammoList[self.gunType])  # select =ammo from gun list
		fontType = "verdana.ttf"
		fontSize=30
		fontColour = (255,50,200) # random colour
		#backColour = (255, 255, 255) #colour of button
		#otherColour = (0,255,0)
		startX, startY = 10, 650
		text1Line = pygame.font.SysFont(fontType, fontSize) # start game text
		text1Line = text1Line.render(text1, True, fontColour)
		image = self.weaponImageList[self.gunType]
		text2Line = pygame.font.SysFont(fontType, fontSize)
		text2Line = text2Line.render(text2, True, fontColour)
		self.canvas.blit(text1Line, (startX, startY))
		textWidth = text1Line.get_width()
		space =3
		nextX = startX + textWidth+ space
		self.canvas.blit(image, (nextX, startY))
		nextX+= (image.get_width()+space)
		self.canvas.blit(text2Line, (nextX, startY))
		scoreText = "Score: %012d"%self.score
		scoreLine= pygame.font.SysFont(fontType, fontSize)
		scoreLine= scoreLine.render(scoreText, True, fontColour)
		scoreLine.set_alpha(90)
		scoreStartX = self.width/2 - scoreLine.get_width()/2 #center text
		scoreStartY = 5
		self.canvas.blit(scoreLine, (scoreStartX, scoreStartY))





	def mainMenuBackGround(self):
		# image from http://fc06.deviantart.net/fs71/f/2010/277/9/c/space_back
		# ground_by_ace_bgi-d302p0x.png
		fontType = "verdana.ttf"
		fontSize=40
		fontColour = (0,0,255) #blue 
		backColour = (255, 255, 255) #colour of button
		otherColour = (0,255,0)
		startX, startY = 10, 500
		self.mainMenuImg = pygame.image.load("mainMenu.png") #main menu background image
		self.mainMenuImg = pygame.transform.scale(self.mainMenuImg, [self.width,self.height])
		startGame = pygame.font.SysFont(fontType, fontSize) # start game text
		startGame = startGame.render("Start", True, fontColour, backColour)
		instructions = pygame.font.SysFont(fontType, fontSize)
		instructions = instructions.render("Instructions", True, fontColour, backColour)
		highscore = pygame.font.SysFont(fontType, fontSize)
		highscore = highscore.render("Highscore", True, fontColour, backColour)
		settings = pygame.font.SysFont(fontType, fontSize)
		settings = settings.render("Settings", True, fontColour, backColour)
		titleSize = (80)
		titleColour = (180,150,120)
		titleFont = "superclarendon.ttf"
		title = pygame.font.SysFont(titleFont, titleSize)
		title = title.render("Space Blaster",True, titleColour)
		self.mainButtonList = [startGame, instructions, highscore, settings]
		self.mainButtonRectList = [] #stores coords of all the main menu buttons
		#startGame = startGame.get_rect(x= 600, y=10)
		self.canvas.blit(self.mainMenuImg, (0,0))
		self.canvas.blit(title, (self.width/2-title.get_width()/2, 40))
		for b in xrange(len(self.mainButtonList)):
			self.canvas.blit(self.mainButtonList[b], (startX, startY))
			button = self.mainButtonList[b].get_rect(x= startX, y=startY)
			self.mainButtonRectList+= [button] 
			startY+= fontSize


	def instructionsPage(self):
		# image fom http://img4.wikia.nocookie.net/
		#__cb20130706130843/asuraswrath/images/2/27/Space.png
		background =pygame.image.load("instructionPage.png") #get the background Picture
		background = pygame.transform.scale(background, [self.width,self.height])
		fontType = "verdana.ttf"
		fontSize=40
		fontColour = (180,180,0) # random colour 
		backColour = (255, 255, 255) #colour of button
		startX, startY = self.width/2, 100
		text0 = "w = move up"
		text1 = "s = move down"
		text2 = "a = move left"
		text3 = "d = move right"
		text4 ="shift = switch between available weapons"
		text5 = "Enter = fire weapon"
		text6 = "p = pause game"
		#text7 = "Backspace = quit game"
		text8 = "Esc = return to main during game"
		text9 = "Main Menu"
		self.instTextList = [text0, text1, text2, text3, text4, text5, text6, text8, text9]
		self.instRectList= []
		# list of all text to be printed
		self.canvas.blit(background, (0,0))
		for text in xrange(len(self.instTextList)):
			if text == (len(self.instTextList)-1):
				printText = pygame.font.SysFont(fontType, fontSize)
				printText = printText.render(self.instTextList[text], True, fontColour, backColour)
			else:
				printText = pygame.font.SysFont(fontType, fontSize)
				printText = printText.render(self.instTextList[text], True, fontColour)
			width = printText.get_width()
			leftShift = -width/2
			self.canvas.blit(printText, (startX+leftShift, startY+ (text*fontSize)))
			if text == len(self.instTextList)-1:
				rect = printText.get_rect(x=startX+leftShift, y=startY+ (text*fontSize))
				self.instRectList += [rect]  #stores coords of buttons

	def highscoresPage(self):
		# image fom http://s257.photobucket.com/user/Catalyst68/media
		#/Utherverse%20Resources/orion-nebula-hubble.png.html
		highScoresList = self.topScores() 
		background =pygame.image.load("nebula.png") #get the background Picture
		background = pygame.transform.scale(background, [self.width,self.height])
		fontType = "verdana.ttf"
		fontSize=40
		fontColour = (20,120,255) # random colour 
		backColour = (255, 255, 255) #colour of button
		startX, startY = self.width/2, self.height/2-200
		text9 = "Main Menu"
		self.HSprintList = highScoresList+["Main Menu"]
		self.HSrectList= []
		# list of all text to be printed
		self.canvas.blit(background, (0,0))
		for text in xrange(len(self.HSprintList)):
			if text == (len(self.HSprintList)-1):
				printText = pygame.font.SysFont(fontType, fontSize)
				printText = printText.render(self.HSprintList[text], True, fontColour, backColour)
			elif (text==0):
				toPrint = "1st   "+self.HSprintList[text]
				printText = pygame.font.SysFont(fontType, fontSize)
				printText = printText.render(toPrint, True, fontColour)
			elif (text==1):
				toPrint = "2nd   "+self.HSprintList[text]
				printText = pygame.font.SysFont(fontType, fontSize)
				printText = printText.render(toPrint, True, fontColour)
			elif (text==2):
				toPrint = "3rd   "+self.HSprintList[text]
				printText = pygame.font.SysFont(fontType, fontSize)
				printText = printText.render(toPrint, True, fontColour)
			else:
				toPrint = "%dth   "%(text+1)+self.HSprintList[text]
				printText = pygame.font.SysFont(fontType, fontSize)
				printText = printText.render(toPrint, True, fontColour)
			width = printText.get_width()
			leftShift = -width/2
			self.canvas.blit(printText, (startX+leftShift, startY+ (text*fontSize)))
			if text == len(self.HSprintList)-1:
				rect = printText.get_rect(x=startX+leftShift, y=startY+ (text*fontSize))
				self.HSrectList += [rect]  #stores coords of buttons

	def settingsPage(self):
		background =pygame.image.load("instructionPage.png") #get the background Picture
		background = pygame.transform.scale(background, [self.width,self.height])
		fontType = "verdana.ttf"
		fontSize=40
		fontColour = (180,180,0) # random colour 
		backColour = (255, 255, 255) #colour of button
		leftShift = 200
		startX, startY = (self.width/2 - leftShift), 100
		#self.settingClass = Settings(startX, startY, fontSize, self.canvas)
		text0 = "SFX:"
		text1 = "Music Volume:"
		text2= "Sensitivity:"
		text3 = "Game Quality:"
		self.setTextList= [text0, text1, text2, text3]
		self.canvas.blit(background, (0,0))
		for text in xrange(len(self.setTextList)):
			printText = pygame.font.SysFont(fontType, fontSize)
			printText = printText.render(self.setTextList[text], True, fontColour)
			self.canvas.blit(printText, (startX, startY+(text*fontSize)))


	def initSettings(self):
		fontSize = 40
		leftShift = 200
		startX, startY = (self.width/2 - leftShift), 100
		self.settingClass = Settings(startX, startY, fontSize, self.canvas)

	def gameOverScreen(self):
		self.canvas.blit(self.deathPic, (0,0))
		text = "Press Backspace to restart"
		fontType = "verdana.ttf"
		fontSize=40
		fontColour= (255,255,255) #white
		printText = pygame.font.SysFont(fontType, fontSize) 
		printText = printText.render(text, True, fontColour)
		downShift= 100 #shift down
		startX = self.width/2
		startY= self.height/2
		leftShift = -printText.get_width()/2 #shift left to center
		self.canvas.blit(printText, (startX+leftShift, startY+downShift))
		if (self.newHighScore()):
			text= "Congraulations New Top Score"
			text2 = "%012d"%self.score
			startX= self.width/2
			upshift =100
			startY = self.height/2 - upshift
			fontColour = (200,50,120)
			PrintText = pygame.font.SysFont(fontType, fontSize) 
			printText = PrintText.render(text, True, fontColour)
			printText2 = PrintText.render(text2, True, fontColour)
			self.canvas.blit(printText, (startX-printText.get_width()/2, startY))
			self.canvas.blit(printText2, (startX-printText2.get_width()/2, startY+fontSize))






	def onMouseDown(self, event):
		X, Y= event.pos[0], event.pos[1]
		if self.mainMenu: # if in main menu	
			for index in xrange(len(self.mainButtonRectList)):
				button = self.mainButtonRectList[index]
				if (button.x<=X<= button.x+button.width and button.y<=Y<=button.y+button.height):
					buttonIndex = index
				else: buttonIndex = None
				#print buttonIndex
				if buttonIndex == 0:
					self.mainMenu =False
					self.startGame =True 
					return 
				elif buttonIndex == 1:
					self.instructionsMenu =True 
					self.mainMenu = False
					return
				elif buttonIndex == 2:
					self.highScoreMenu =True #have not made yet
					self.mainMenu =False
					return
				elif buttonIndex == 3:
					self.settings = True 
					self.mainMenu =False
					return
		elif(not self.mainMenu and self.instructionsMenu):
			startY = self.instRectList[0].y # y coord of first printed line
			width = self.instRectList[0].width
			height = self.instRectList[0].height
			startX = self.instRectList[0].x
			if (startX<=X<=startX+width and startY<=Y<=startY+height):
				self.mainMenu =True
				self.instructionsMenu=False
				#working fine
		elif(not self.mainMenu and self.settings):
			self.settingClass.selectChange(X, Y)
			self.mainSound.set_volume(self.settingClass.vol) #change volume
			SFX = self.settingClass.SFXvol
			self.changeSFXvol(SFX)
			self.mainMenu = self.settingClass.mainMenu
			self.settings= self.settingClass.setting
			self.gameQuality = self.settingClass.spec
			self.vel = self.settingClass.sensitivity
			#print self.mainMenu,self.settingClass.mainMenu
		elif(not self.mainMenu and self.highScoreMenu):
			startY = self.HSrectList[0].y
			startX = self.HSrectList[0].x
			width = self.HSrectList[0].width
			height =  self.HSrectList[0].height
			if (startX<=X<=startX+width and startY<=Y<=startY+height):
				self.mainMenu =True
				self.highScoreMenu=False

			



	def onKeyDown(self,event):
		if self.gameOver:
			if (event.key== K_SPACE): 
				self.initAnimation()
			if (event.key==K_BACKSPACE):
				self.restartGame()
		if (event.key== K_w):
			self.dy= -self.vel
		elif (event.key==K_s):
			self.dy= self.vel
		elif (event.key== K_a):
			self.dx= -self.vel
		elif (event.key==K_d):
			self.dx= self.vel
		if (event.key==K_LSHIFT):
			self.selectGunLeft()
		elif (event.key == K_RSHIFT):
			self.selectGun()
		if (event.key== K_RETURN): 
			self.gunFired= True
		if (event.key == K_p):
			self.gamePaused =True
		if (event.key==K_ESCAPE):
			self.initAnimation()

	

	

	def onTimerFired(self):
		self.checkCollision() # check collision between bullet and enemies
		#print self,checkOnScreenEnemies()
		
		if self.checkBossSpawn(): #if time for boss spawn
			self.enemyAI.bossEnemySpawn(self.bossGroup,self.level)
			self.enemyAI.randomGoonSpawn(self.randomGoons, 1) 
		elif self.checkOnScreenEnemies() and (len(self.bossGroup.sprites())==0): 
		#if spawn cap not reached and if no boss alive
			self.enemyAI.randomGoonSpawn(self.randomGoons, self.level)
			self.enemyAI.advancedEnemySpawn(self.advancedEnemies, self.level)
		self.powerUpCreation.randomPowerUpSpawn(self.powerUpGroup)
		#if len(self.enemies.sprites())<1:
		#	self.enemies.add(goons(20,200))
		#else:
		#	for sprite in self.enemies.sprites(): #move enemies
		#			sprite.move()
		for sprite in self.powerUpGroup.sprites():
			sprite.move()
			if sprite.rect.y>=800:
				sprite.kill()
		for sprite in self.bossGroup.sprites():
			sprite.move(self.playerGroup)
		for sprite in self.randomGoons.sprites():
			sprite.moveDown()
			sprite.fireWeapon(self.enemyProjectiles, self.level)
		for sprite in self.advancedEnemies.sprites():
			sprite.move(self.playerGroup)
			sprite.fireWeapon(self.playerGroup, self.enemyProjectiles, self.enemyAimedProjectileGroup, self.level)
		for sprite in self.bossGroup.sprites():
			sprite.fireWeapon(self.enemyAimedProjectileGroup ,self.level)
		if (len(self.newProjectileList.sprites())>0): 
		#keep moving player if key down
				for sprite in self.newProjectileList.sprites():
					sprite.move()
					if sprite.rect.y<=(1):
						self.newProjectileList.remove(sprite)
		for bullet in self.enemyAimedProjectileGroup.sprites():
			#aimed projectiles
			bullet.move()      
		for sprite in self.missileProjectile.sprites():
			#homing missiles
					sprite.homeMissile(self.enemies, self.randomGoons)
					if (sprite.rect.y<=(1) or sprite.rect.y>700 or sprite.rect.x<0 or sprite.rect.x>780):
						sprite.kill()
		for bullet in self.enemyProjectiles.sprites():
			#normal enemy bullets
			bullet.moveDown()
			if bullet.rect.y>=(800):
						bullet.kill()
						 # clear from screen after certain distance
		if self.gunFired:
			self.weapons[self.availableWeapons[self.gunType]]()
			if ((self.gunType == 1 or self.gunType==0) and self.ammoList[self.gunType]>0):
				# play sound only if there is ammo and is machine gun
				a=2
				self.machineGunChannel.play(self.machineGunAudio, loops=1, maxtime=400)
			elif (self.gunType == 2) and self.ammoList[self.gunType]>0: 
				self.rocketLaunchChannel.play(self.rocketLaunchAudio, loops=1, maxtime=400)
			#self.machineGunAudio.play(loops=1, maxtime=400)
			# fire currently selected weapon
		self.levelChecker()
		self.difficultyScaler()
		#print self.level,self.enemyNumCap

	def onKeyUp(self, event):
		if (event.key== K_w or event.key== K_s ):
						self.dy= 0
		elif (event.key== K_a or event.key== K_d ):
						self.dx= 0
		if (event.key== K_RETURN):
			self.gunFired= False

	def updateAll(self):
		if self.mainMenu:  
			self.mainMenuBackGround()
		elif (not self.mainMenu and self.instructionsMenu):
			self.instructionsPage()
		elif ((not self.mainMenu) and self.settings):
			self.settingsPage()	
			self.settingClass.drawAll()
			#print self.settingClass.call
		elif ((not self.mainMenu) and self.highScoreMenu):
			self.highscoresPage()	
		elif (not self.gameOver):
			self.moveTank(self.dx, self.dy)		
			self.backgroundImage(self.canvas)
			self.createTank(self.tankX, self.tankY)
			#self.newProjectileList.draw(self.canvas)
			self.drawBullets()
			#self.missileProjectile.draw(self.canvas)
			self.drawHomingMissile()
			#self.enemies.draw(self.canvas)
			self.drawEnemy(self.enemies, self.randomGoons, self.advancedEnemies, self.bossGroup)
			#self.enemyProjectiles.draw(self.canvas)
			#self.enemyAimedProjectileGroup.draw(self.canvas)
			self.drawExplosions()
			self.drawPowerUps()
			self.drawHUD()
		else: #gameOVer
			self.gameOverScreen()
			#self.canvas.blit(self.fuck.test, (0,0))



	def run(self):
		self.canvas= pygame.display.set_mode((self.width, self.height))
		self.canvas.fill((200,100,10))
		#self.fuck= newProjectile(150, 300, self.canvas)
		self.initSettings() #init in game setings
		self.initAnimation()
		self.initSounds() # init all in game sounds
		#self.initAnimation()
		self.mainSoundChannel.play(self.mainSound, loops=-1)
		while True:
			for event in pygame.event.get():
				if (event.type== QUIT): #quit program
					pygame.quit()
					sys.exit()
				elif (not self.gameOver and not self.mainMenu and self.startGame):
					if (event.type== KEYDOWN):
						self.onKeyDown(event)
					if event.type== KEYUP:
						self.onKeyUp(event)
				if( not self.startGame): 
					if event.type == MOUSEBUTTONDOWN:
						self.onMouseDown(event)
				elif(self.gameOver):
					if (event.type== KEYDOWN):
						self.onKeyDown(event)
			if ((not self.gameOver )and (not self.mainMenu) and (self.startGame)):
				# if game is in progress
				self.onTimerFired()
					#mouse button 
			#self.startTimer+= /1000.0
			self.gameTimer.tick()
			#if self.startTimer>1:
			#	print self.startTimer	
			self.updateAll()
			#self.canvas.blit(self.fuck.test, (0,0))
			pygame.display.update()
			#same as redraw all
			#place at end of loop



a=TermProject()
a.run()

#print pygame.font.get_fonts()


